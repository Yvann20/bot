import os
import re
import asyncio
from dotenv import load_dotenv
from telethon import TelegramClient, events
from telethon.errors import SessionPasswordNeededError, PhoneCodeInvalidError, PhoneNumberInvalidError, SessionRevokedError
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# Carregar variáveis do .env
load_dotenv()
API_ID = int(os.getenv("API_ID"))
API_HASH = os.getenv("API_HASH")
BOT_TOKEN = os.getenv("BOT_TOKEN")
TARGET_CHANNEL = os.getenv("TARGET_CHANNEL")
TARGET_BOT = os.getenv("TARGET_BOT")
ADMIN_USER_ID = int(os.getenv("ADMIN_USER_ID"))

SESSION_NAME = "user_session"
SESSION_FILE = f"{SESSION_NAME}.session"
client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

monitorando = False
monitor_task = None

def session_cleanup():
    if os.path.exists(SESSION_FILE):
        os.remove(SESSION_FILE)
        print("[!] Sessão removida para limpar dados corrompidos/inválidos.")

async def conectar_telethon():
    global client
    while True:
        try:
            await client.connect()
            if not await client.is_user_authorized():
                print("[!] Sessão não autorizada. Iniciando login...")
                phone = input("📱 Digite seu número com DDI (ex: +55XXXXXXXXX): ")
                try:
                    await client.send_code_request(phone)
                except PhoneNumberInvalidError:
                    print("[❌] Número inválido. Tente novamente.")
                    continue
                code = input("📩 Digite o código que chegou no Telegram: ")
                try:
                    await client.sign_in(phone, code)
                except PhoneCodeInvalidError:
                    print("[❌] Código inválido. Tente novamente.")
                    continue
                except SessionPasswordNeededError:
                    pw = input("🔐 Sua conta tem autenticação de 2 fatores. Digite a senha: ")
                    await client.sign_in(password=pw)
                print("[✔] Sessão criada e salva com sucesso!")
            else:
                print("[✔] Sessão conectada.")
            break
        except (SessionRevokedError, RuntimeError) as e:
            print(f"[!] Sessão inválida ou revogada: {e}")
            session_cleanup()
            client = TelegramClient(SESSION_NAME, API_ID, API_HASH)
        except Exception as e:
            print(f"[❌] Erro inesperado: {e}")
            session_cleanup()
            client = TelegramClient(SESSION_NAME, API_ID, API_HASH)

async def start_monitoramento(app):
    @client.on(events.NewMessage(chats=TARGET_CHANNEL if TARGET_CHANNEL.startswith("@") else int(TARGET_CHANNEL)))
    async def handler(event):
        global monitorando
        if not monitorando:
            return
        msg = event.message.message
        match = re.search(r"(/resgatar\s+[A-Z0-9]+)", msg)
        if match:
            codigo = match.group(1)
            try:
                await client.send_message(TARGET_BOT, codigo)
                print(f"[✔] Código enviado: {codigo}")
                # Avisar o admin no bot (com HTML, seguro!)
                try:
                    await app.bot.send_message(
                        chat_id=ADMIN_USER_ID,
                        text=f"✅ Código enviado para {TARGET_BOT}: <code>{codigo}</code>",
                        parse_mode="HTML"
                    )
                except Exception as e:
                    print(f"[❌] Não consegui avisar no bot: {e}")
            except Exception as e:
                print(f"[❌] Erro ao enviar código: {e}")
                try:
                    await app.bot.send_message(
                        chat_id=ADMIN_USER_ID,
                        text=f"❌ Erro ao enviar código: <code>{e}</code>",
                        parse_mode="HTML"
                    )
                except:
                    pass
    await client.run_until_disconnected()

async def safe_monitor_task(app):
    try:
        await start_monitoramento(app)
    except Exception as e:
        print(f"[❌] Erro no monitoramento: {e}")

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    status = "🟢 Ativo" if monitorando else "🔴 Parado"
    await update.message.reply_text(f"🤖 Monitor de códigos\nStatus: {status}")

async def startmonitor_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global monitorando, monitor_task
    if monitorando:
        await update.message.reply_text("⚠️ Já está monitorando.")
        return
    monitorando = True
    await update.message.reply_text("✅ Monitoramento iniciado.")
    # Cria uma task se não existir
    if monitor_task is None or monitor_task.done():
        monitor_task = asyncio.create_task(safe_monitor_task(context.application))

async def stopmonitor_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global monitorando
    monitorando = False
    await update.message.reply_text("🛑 Monitoramento parado.")

async def status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    status = "🟢 Ativo" if monitorando else "🔴 Parado"
    await update.message.reply_text(f"Status do monitoramento: {status}")

async def main():
    global monitor_task
    await conectar_telethon()

    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start_handler))
    app.add_handler(CommandHandler("startmonitor", startmonitor_handler))
    app.add_handler(CommandHandler("stopmonitor", stopmonitor_handler))
    app.add_handler(CommandHandler("status", status_handler))

    print("[BOT] Iniciado")
    # Inicia o Telethon monitorando em paralelo
    monitor_task = asyncio.create_task(safe_monitor_task(app))
    await app.run_polling()

if __name__ == "__main__":
    import sys
    try:
        import nest_asyncio
        nest_asyncio.apply()
    except ImportError:
        pass
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            loop.create_task(main())
        else:
            loop.run_until_complete(main())
    except RuntimeError:
        asyncio.run(main())
